<?php
$response = "acknowledgement_required";

$message = "Note: You can use a purchase code only for single site. If you use same purchase code on multiple sites, the application will stop working.";

return array("response_type"=>$response, "message"=>$message);