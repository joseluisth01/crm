ALTER TABLE `help_articles` ADD COLUMN `related_article_ids` text NULL;#

ALTER TABLE `tasks` CHANGE `sort` `sort` double NOT NULL DEFAULT '0';#

ALTER TABLE `reminder_settings`
CHANGE `reminder1` `reminder1` varchar(255) NULL,
ADD `user_id` int(11) DEFAULT 0;#

ALTER TABLE `reminder_logs`
ADD `reminder_time` time DEFAULT NULL,
ADD `notify_to` mediumtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL;#

ALTER TABLE `events`
ADD `event_id` int(11) DEFAULT 0;#

ALTER TABLE `notifications`
ADD `reminder_id` int(11) DEFAULT 0;#

INSERT INTO `notification_settings` 
(`event`, `category`, `enable_email`, `enable_web`, `enable_slack`, `notify_to_team`, `notify_to_team_members`, `notify_to_terms`, `sort`, `deleted`) VALUES 
('upcoming_event', 'event', '0', '0', '0', '', '', '', '81', '0'),
('upcoming_reminder', 'reminder', '0', '0', '0', '', '', '', '82', '0');#

INSERT INTO `email_templates` 
(`template_name`, `email_subject`, `default_message`, `custom_message`, `template_type`, `language`, `deleted`) VALUES 
('upcoming_event', 'Upcoming Event', '<div style="background-color: #eeeeef; padding: 50px 0; "> <div style="max-width:640px; margin:0 auto; "> <div style="color: #fff; text-align: center; background-color:#33333e; padding: 30px; border-top-left-radius: 3px; border-top-right-radius: 3px; margin: 0;"><h1>Upcoming Event</h1></div><div style="padding: 20px; background-color: rgb(255, 255, 255);"><p style=""><span style="line-height: 18.5714px;">Hello, </span></p><p style=""><span style="line-height: 18.5714px;">There is an&nbsp;</span>upcoming event. Please check the details below:</p><p style=""><span style="line-height: 18.5714px; font-weight: bold;"><br></span></p><p style=""><span style="line-height: 18.5714px; font-weight: bold;">Title: </span><span style="line-height: 18.5714px;">{EVENT_TITLE}</span></p><p style=""><span style="line-height: 18.5714px;"><b>Event time:&nbsp;</b></span>{EVENT_DATE_TIME}</p><p style=""><span style="line-height: 18.5714px;">{EVENT_DESCRIPTION}</span></p><p style=""><br></p><p style=""><span style="color: rgb(85, 85, 85); font-size: 14px; line-height: 20px;"><a style="background-color: #00b393; padding: 10px 15px; color: #ffffff;" href="{EVENT_URL}" target="_blank">Show Event</a></span></p><p style=""><br></p><p style="">{SIGNATURE}</p></div></div></div>', '', 'default', '', '0'),
('upcoming_reminder', 'Upcoming Reminder', '<div style="background-color: #eeeeef; padding: 50px 0; "> <div style="max-width:640px; margin:0 auto; "> <div style="color: #fff; text-align: center; background-color:#33333e; padding: 30px; border-top-left-radius: 3px; border-top-right-radius: 3px; margin: 0;"><h1>Upcoming Reminder</h1></div><div style="padding: 20px; background-color: rgb(255, 255, 255);"><p style=""><span style="line-height: 18.5714px;">Hello, </span></p><p style=""><span style="line-height: 18.5714px;">There is an&nbsp;</span>upcoming reminder. Please check the details below:</p><p style=""><span style="line-height: 18.5714px; font-weight: bold;"><br></span></p><p style=""><span style="line-height: 18.5714px; font-weight: bold;">Title: </span><span style="line-height: 18.5714px;">{REMINDER_TITLE}</span></p><p style=""><span style="line-height: 18.5714px;"><b>Reminder time:&nbsp;</b></span>{REMINDER_DATE_TIME}</p><p style=""><br></p><p style=""><span style="color: rgb(85, 85, 85); font-size: 14px; line-height: 20px;"><a style="background-color: #00b393; padding: 10px 15px; color: #ffffff;" href="{REMINDER_URL}" target="_blank">Show Reminder</a></span></p><p style=""><br></p><p style="">{SIGNATURE}</p></div></div></div>', '', 'default', '', '0');#
