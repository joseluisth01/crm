<?php

try {

    $db = db_connect('default');
    $dbprefix = $db->getPrefix();

    if (!$dbprefix) {
        $dbprefix = "";
    }

    $upgrade_sql = "upgrade-3.9.5.sql";
    $sql = file_get_contents($upgrade_sql);

    if ($dbprefix) {
        $sql = str_replace('CREATE TABLE IF NOT EXISTS `', 'CREATE TABLE IF NOT EXISTS `' . $dbprefix, $sql);
        $sql = str_replace('INSERT INTO `', 'INSERT INTO `' . $dbprefix, $sql);
        $sql = str_replace('ALTER TABLE `', 'ALTER TABLE `' . $dbprefix, $sql);
        $sql = str_replace('DELETE FROM `', 'DELETE FROM `' . $dbprefix, $sql);
        $sql = str_replace('UPDATE `', 'UPDATE `' . $dbprefix, $sql);
        $sql = str_replace('DROP TABLE `', 'DROP TABLE `' . $dbprefix, $sql);
    }

    foreach (explode(";#", $sql) as $query) {
        $query = trim($query);
        if ($query) {
            try {
                $db->query($query);
            } catch (\Exception $ex) {
                log_message("error", $ex->getTraceAsString());
            }
        }
    }

    unlink($upgrade_sql);

    function curl_get_verification($url) {
        $ch = curl_init();

        curl_setopt($ch, CURLOPT_HEADER, 0);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_HTTPGET, TRUE);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 30);
        curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/4.0 (compatible; MSIE 5.01; Windows NT 5.0)");
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-type: text/plain'));

        $data = curl_exec($ch);
        curl_close($ch);

        //try with file_get_contents 
        if (!$data) {
            $data = file_get_contents($url);
        }

        return $data;
    }

    $Settings_model = model('App\Models\Settings_model');
    $item_purchase_code = get_setting("item_purchase_code");

    if ($item_purchase_code) {
        $item_purchase_code = trim($item_purchase_code);
        $item_purchase_code = urlencode($item_purchase_code);

        $url = "https://releases.fairsketch.com/rise/?api_version=2&type=install&code=" . $item_purchase_code . "&domain=" . $_SERVER['HTTP_HOST'];

        $verification = curl_get_verification($url);

        if ($verification && strpos($verification, 'verified') === 0) {
            $app_verification_key = substr($verification, 8);
            $Settings_model->save_setting("app_verification_key", $app_verification_key);
        }
    }

    helper("filesystem");
    delete_files("app/Views/leads/tickets",  true, false, true);

    delete_files("assets/js/datatable/css",  true, false, true);
    delete_files("assets/js/datatable/js",  true, false, true);
    delete_files("assets/js/datatable/TableTools",  true, false, true);
    
} catch (\Exception $exc) {
    log_message("error", $exc->getTraceAsString());
    echo $exc->getTraceAsString();
}
