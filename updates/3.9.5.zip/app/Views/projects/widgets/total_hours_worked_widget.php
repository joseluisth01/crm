<div class="card widget-card">
    <div class="card-body">
        <div class="d-flex">
            <div class="flex-shrink-0 text-off align-self-center">
                <i data-feather="clock" width="5rem" height="5rem"></i>
            </div>
            <div class="w-100 text-end">
                <h1><?php echo $total_project_hours; ?></h1>
                <?php echo app_lang("total_hours_worked"); ?>
            </div>
        </div>
    </div>
</div>